package com.requestshorter.entityapi

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class EntityApiApplication {

	static void main(String[] args) {
		SpringApplication.run(EntityApiApplication, args)
	}

}
