package com.requestshorter.entityapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class EntityApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
