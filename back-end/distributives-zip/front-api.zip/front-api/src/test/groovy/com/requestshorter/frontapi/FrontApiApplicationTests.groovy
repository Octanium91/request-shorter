package com.requestshorter.frontapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class FrontApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
