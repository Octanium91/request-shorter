package com.requestshorter.scheduler

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SchedulerApplicationTests {

	@Test
	void contextLoads() {
	}

}
